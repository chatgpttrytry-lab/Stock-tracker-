# SATRUGHAN SWING TRADING STOCK TRACKER — Free setup

## Files
- `index.html` — browser/GitHub Pages interface.
- `Code.gs` — Google Apps Script bridge that reads Google Sheets GOOGLEFINANCE quotes.
- `README.txt` — this setup guide.

## Important data limits
- Google Sheets `GOOGLEFINANCE()` quotes may be delayed up to 20 minutes; refresh button refreshes the page data, not Google's underlying quote feed.
- Google Finance does not support every ticker/market/field. Use `NSE:ITC`, `NSE:RELIANCE`, `NSE:TCS`, etc. BSE examples may use `BSE:500875`.
- The app intentionally shows no fake/demo quote values.
- TradingView's embedded chart is a separate chart widget; its symbol coverage and price timing may differ from Google Sheets.
- This version does NOT claim fully calculated EMA/RSI/MACD swing signals. Google says historical GOOGLEFINANCE values cannot be retrieved via Apps Script. Do not trade from a WAIT/price-only display.
- This is for information/learning, not investment advice.

## Setup (mobile or desktop)
1. Open https://sheets.new and create a blank Google Sheet named `SATRUGHAN Stock Tracker`.
2. In the Sheet, open Extensions → Apps Script.
3. Delete the starter code and paste all content from `Code.gs`. Save the project.
4. In the function dropdown, select `setupTracker` and press Run. Approve the Google permissions prompt. It creates a `Quotes` tab with sample *symbols only* (no fabricated prices).
5. Deploy → New deployment → select type `Web app`.
6. Set “Execute as” to `Me`. Set access to `Anyone` if you want the GitHub Pages page to call it without a Google sign-in (only share the web app URL, never share the spreadsheet editor URL). Deploy and copy the URL ending in `/exec`.
7. Open `index.html` in a text editor. Find:
   `const SCRIPT_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";`
   Replace the placeholder with the deployed `/exec` URL. Keep the URL inside the quotes.
8. Save `index.html`. Upload `index.html` to your GitHub repository and enable GitHub Pages, or open it in a browser. The Apps Script URL must be filled first.
9. Open the site, search a ticker like `NSE:ITC`, and tap Search / Add. It will add the ticker to the Quotes sheet if not already present. Wait a little for Google Finance formulas to calculate, then tap Refresh.

## Add more symbols
Use the search field and enter an exchange-prefixed ticker:
- `NSE:ITC`
- `NSE:RELIANCE`
- `NSE:TCS`
- `NSE:INFY`
- `BSE:500875`

If a symbol is unsupported by Google Finance, the quote cells stay blank rather than showing fake prices.

## If you update Code.gs after deployment
Deploy → Manage deployments → Edit (pencil) → select New version → Deploy. Use the same `/exec` URL unless you create a new deployment.

## Privacy / access
The web app is configured to run as the script owner. Anyone who has the URL can call its read/add endpoints if access is set to Anyone, so do not store private data in this spreadsheet. Do not share credentials or authorization tokens. The HTML uses JSONP to avoid browser cross-origin fetch restrictions; it does not contain a secret key.

## Common troubleshooting
- “Setup ବାକି”: the script URL is still the placeholder.
- “Quotes sheet not found”: run `setupTracker()` once.
- Blank prices: ticker unsupported, market closed, or GOOGLEFINANCE has not calculated yet.
- Chart blank/wrong: check TradingView symbol search in its chart selector.
- Auto refresh runs every 60 seconds, but GoogleFinance can still be delayed up to 20 minutes.
