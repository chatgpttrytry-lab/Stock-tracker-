const SHEET_NAME = 'Quotes';
const HEADERS = ['Symbol','Price','Change','Change %','Open','High','Low','Previous Close','Volume','Market Cap','P/E','52W High','52W Low','Last Trade Time','Data Delay (min)'];

function setupTracker() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  sh.clear();
  sh.getRange(1,1,1,HEADERS.length).setValues([HEADERS]);
  sh.getRange(2,1,6,1).setValues([['NSE:ITC'],['NSE:RELIANCE'],['NSE:TCS'],['NSE:INFY'],['NSE:SBIN'],['NSE:HDFCBANK']]);
  for (let r=2;r<=7;r++) writeFormulas_(sh,r);
  sh.setFrozenRows(1);
  sh.getRange(1,1,1,HEADERS.length).setFontWeight('bold').setBackground('#17365d').setFontColor('#ffffff');
  sh.autoResizeColumns(1,HEADERS.length);
  SpreadsheetApp.flush();
  return 'Setup complete. Quotes sheet created.';
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  const callback = String(p.callback || '');
  try {
    const action = String(p.action || 'list').toLowerCase();
    if (action === 'add') addSymbol_(String(p.symbol || ''));
    const result = {ok:true, rows:readRows_()};
    return output_(result, callback);
  } catch (err) {
    return output_({ok:false,error:String(err && err.message || err),rows:[]}, callback);
  }
}

function addSymbol_(raw) {
  const symbol = normalizeSymbol_(raw);
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) throw new Error('Quotes sheet ମିଳିଲା ନାହିଁ। ପ୍ରଥମେ setupTracker() Run କରନ୍ତୁ।');
  const last = sh.getLastRow();
  const existing = last > 1 ? sh.getRange(2,1,last-1,1).getDisplayValues().flat().map(x=>x.toUpperCase()) : [];
  if (existing.includes(symbol)) return;
  const r = Math.max(2,last+1);
  sh.getRange(r,1).setValue(symbol);
  writeFormulas_(sh,r);
  SpreadsheetApp.flush();
}

function normalizeSymbol_(raw) {
  let s = String(raw || '').trim().toUpperCase().replace(/\s+/g,'');
  if (!s) throw new Error('Stock symbol ଲେଖନ୍ତୁ, ଯେପରି NSE:ITC');
  if (!/^[A-Z0-9&._:-]{1,30}$/.test(s)) throw new Error('Symbol ରେ ଅବୈଧ ଅକ୍ଷର ଅଛି।');
  if (!s.includes(':')) s = 'NSE:' + s;
  if (!/^(NSE|BSE):[A-Z0-9&._-]+$/.test(s)) throw new Error('Format: NSE:ITC କିମ୍ବା BSE:500875');
  return s;
}

function writeFormulas_(sh,r) {
  const sym = '$A'+r;
  const attrs = ['price','change','changepct','priceopen','high','low','closeyest','volume','marketcap','pe','high52','low52','tradetime','datadelay'];
  // B:O correspond to attributes. IFERROR keeps unsupported fields blank.
  attrs.forEach((attr,i) => {
    const col = i+2;
    sh.getRange(r,col).setFormula('=IFERROR(GOOGLEFINANCE('+sym+',"'+attr+'"),"")');
  });
}

function readRows_() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sh) throw new Error('Quotes sheet ମିଳିଲା ନାହିଁ। setupTracker() Run କରନ୍ତୁ।');
  const last=sh.getLastRow();
  if(last<2) return [];
  const vals=sh.getRange(2,1,last-1,HEADERS.length).getValues();
  return vals.filter(r=>r[0]).map(r=>({
    symbol:String(r[0]), price:num_(r[1]), change:num_(r[2]), changepct:num_(r[3]),
    open:num_(r[4]), high:num_(r[5]), low:num_(r[6]), prevclose:num_(r[7]),
    volume:num_(r[8]), marketcap:num_(r[9]), pe:num_(r[10]), high52:num_(r[11]),
    low52:num_(r[12]), tradetime:r[13] instanceof Date ? r[13].toISOString() : String(r[13]||''),
    datadelay:num_(r[14])
  }));
}

function num_(v) {
  if(v==='' || v===null || v===undefined || typeof v==='string' && v.trim()==='') return null;
  const n=Number(v); return Number.isFinite(n)?n:null;
}

function output_(obj, callback) {
  const json=JSON.stringify(obj);
  if(callback && /^[A-Za-z_$][0-9A-Za-z_$]*$/.test(callback)) {
    return ContentService.createTextOutput(callback+'('+json+');').setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}